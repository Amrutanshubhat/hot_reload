#include <iostream>

using namespace std;

int main() {
	int a, b, alpha;
	cout<<"Enter (x, y) of v1"<<endl;
	cin>>a>>b;	
	cout<<"Enter alpha: "<<endl;
	cin>>alpha;
	printf("output: (%d, %d)\n", a*alpha, b*alpha);
}




	
