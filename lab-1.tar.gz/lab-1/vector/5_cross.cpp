#include <iostream>
#inlcude <fstream>

using namespace std;

int main() {
	ifstream ifs{"input.txt", std::ifstream::in};
}




	
