#include <iostream>

using namespace std;

int main() {
	int a, b, x, y;
	cout<<"Enter (x, y) of v1"<<endl;
	cin>>a>>b;	
	cout<<"Enter (x, y) of v2"<<endl;
	cin>>x>>y;	
	printf("sum is: (%d, %d)\n", a+x, b+y);
}




	
