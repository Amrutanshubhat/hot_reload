#include <iostream>
#include <cmath>

using namespace std;

int main() {
	int a, b;
	cout<<"Enter (x, y) of v1"<<endl;
	cin>>a>>b;	
	printf("length: %.2lf\n", sqrt(a*a + b*b));
}




	
