#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void print_matrix(vector<vector<int>>& v)
{
	for (int i=0; i<v.size(); i++) {
		for (int j=0; j<v[i].size(); j++) {
			cout<<v[i][j]<<" ";
		}
		cout<<endl;
	}
}

vector<vector<int>> matrix_add(vector<vector<int>>& a, vector<vector<int>>& b)
{
	int m = a.size(), n = b.front().size();
	vector<vector<int>> out(m, vector<int>(n));

	for (int i=0; i<m; i++)
		for (int j=0; j<n; j++)
			out[i][j] = a[i][j] + b[i][j];
	return out;
}

vector<vector<int>> matrix_mul(vector<vector<int>>& a, vector<vector<int>>& b)
{
	int m1 = a.size(), n1 = a.front().size();
	int m2 = b.size(), n2 = b.front().size();

	vector<vector<int>> out;
	if (n1 != m2) {
		return out;
	}

	out.resize(m1, vector<int>(n2));
	for (int i=0; i<m1; i++)
		for (int j=0; j<n2; j++)
			for (int k=0; k<n1; k++)
				out[i][j] += a[i][k]*b[k][j];
	return out;
}

vector<vector<int>> transpose(vector<vector<int>>& a)
{
	int m = a.size(), n = a.front().size();
	vector<vector<int>> out(n, vector<int>(m));

	for (int i=0; i<m; i++)
		for (int j=0; j<n; j++)
			out[j][i] = a[i][j];
	return out;
}

int main() {
	std::ifstream ifs{"input.txt", std::ifstream::in};

	auto read_input = [&](vector<vector<int>>& v)
	{
		int m = v.size(), n = v.front().size();
		for (int i=0; i < m; i++)
			for (int j = 0; j<n; j++)
				ifs>>v[i][j];
	};

	int m, n;
	ifs>>m>>n;
	vector<vector<int>> a(m, vector<int>(n));
	read_input(a);

	ifs>>m>>n;
	vector<vector<int>> b(m, vector<int>(n));
	read_input(b);

	printf("Matrix A:\n");
	print_matrix(a);

	printf("Matrix B:\n");
	print_matrix(b);

	// matrix addition
	auto add = matrix_add(a, b);
	printf("Addition: \n");
	print_matrix(add);

	// matrix multiplication
	printf("Multiplication: \n");
	auto mul = matrix_mul(a, b);
	if (mul.empty())
		cout<<"Invalid Input\n";
	else
		print_matrix(mul);

	//matrix transpose
	printf("Transpose A:\n");
	auto ta = transpose(a);
	print_matrix(ta);

	printf("Transpose B:\n");
	auto tb = transpose(b);
	print_matrix(tb);
}
